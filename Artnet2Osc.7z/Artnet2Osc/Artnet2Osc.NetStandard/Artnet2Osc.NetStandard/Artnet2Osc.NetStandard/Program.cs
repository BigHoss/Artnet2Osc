﻿using System;
using System.Net;

namespace Artnet2Osc.NetStandard
{
    class Program
    {
        public static byte[] DmxData { get; set; }
        public static SharpOSC.UDPSender UdpSender { get; set; }
        static void Main(string[] args)
        {
            DmxData = new byte[511];
            UdpSender = new SharpOSC.UDPSender("127.0.0.1", 55555);
            var artnet = new ArtNet.Sockets.ArtNetSocket
            {
                EnableBroadcast = Properties.Settings.Default.ArtnetBroadCast
            };

            Console.WriteLine(artnet.BroadcastAddress.ToString());

            artnet.Open(IPAddress.Parse("127.0.0.1"), IPAddress.Parse("255.255.255.0"));


            artnet.NewPacket += Artnet_NewPacket;

            Console.ReadLine();
        }

        private static void Artnet_NewPacket(object sender, ArtNet.Sockets.NewPacketEventArgs<ArtNet.Packets.ArtNetPacket> e)
        {
            if (e.Packet.OpCode == ArtNet.Enums.ArtNetOpCodes.Dmx)
            {
                var packet = e.Packet as ArtNet.Packets.ArtNetDmxPacket;
                Console.Clear();

                if (packet.DmxData != DmxData)
                {
                    Console.WriteLine("new Packet");
                    for (int i = 0; i < packet.DmxData.Length; i++)
                    {
                        if (packet.DmxData[i] != 0)
                        {
                            var message = new SharpOSC.OscMessage("/blaparameter/1", 12, 13, "bla");
                            UdpSender.Send(message);
                            Console.WriteLine(i + " = " + packet.DmxData[i]);
                        }

                    }
                }
            }
        }
    }
}
