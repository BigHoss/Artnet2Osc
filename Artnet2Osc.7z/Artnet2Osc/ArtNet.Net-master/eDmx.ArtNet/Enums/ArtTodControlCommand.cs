﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArtNet.Enums
{
    public enum ArtTodControlCommand
    {
        AtcNone = 0,
        AtcFlush = 1
    }
}
