﻿using System;

namespace eDmx.ArtNet
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}

