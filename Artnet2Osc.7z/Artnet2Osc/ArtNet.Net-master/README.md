# ArtNet.Net
An ArtNet library for C# and VB.Net developers. Based on the [Architecture for Control Networks (ACN)](http://acn.codeplex.com) project codebase

##Key Differences
* Removed RDM
* Removed all code unrelated to ArtNet

##Sample Projects
* C# Console app
* VB.Net Console app
